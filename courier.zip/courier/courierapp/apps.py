from django.apps import AppConfig


class CourierappConfig(AppConfig):
    name = 'courierapp'
