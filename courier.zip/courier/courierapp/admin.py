from django.contrib import admin
from courierapp.models import *
# Register your models here.
admin.site.register(RegModels)
admin.site.register(BackendModel)
admin.site.register(Member)
admin.site.register(cmpModel)